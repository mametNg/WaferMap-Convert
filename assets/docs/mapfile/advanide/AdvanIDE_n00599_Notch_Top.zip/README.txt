===============================================================================
Export Classification: EAR99

This document contains controlled technology under the jurisdiction of the
Export Administration Regulations (EAR), 15 CFR 730-774. It cannot be
transferred to any foreign party without the appropriate authorization under
the EAR. Violations of these regulations are punishable by fine, imprisonment,
or both.
===============================================================================

EGView Web die pick map creation report for lot: n00599

Creation Date: 04/12/2024 11:49:34
EGView Web Version: 6.30

  Notch Location: Top
  Rotation Angle Applied from Original: 180 degrees (clockwise)


Wafer Name             Bin 1   Bin 4   Bin 6   Bin 7   Bin 8    Total
====================  ======= ======= ======= ======= =======  =======
N00599-01-F2          18933      46       2       3       6    18990 
N00599-03-C5          18967      22       0       1       0    18990 
N00599-05-A0          18980       6       0       1       3    18990 
N00599-07-E6          18953      35       0       0       2    18990 
N00599-09-C1          18957      31       0       0       2    18990 
N00599-12-E4          18943      45       0       2       0    18990 
N00599-14-B7          18935      53       0       1       1    18990 
N00599-16-G5          18916      68       0       3       3    18990 
N00599-18-E0          18945      44       0       1       0    18990 
N00599-20-E0          18952      37       0       0       1    18990 
N00599-22-B3          18937      49       0       2       2    18990 
N00599-24-G1          18877     111       0       0       2    18990 


Summary Stats
============================================================
Number of die pick map files created:               12
Number of die pick map errors observed:             0
Number of die pick maps with row/column mismatches: 0
