===============================================================================
Export Classification: EAR99

This document contains controlled technology under the jurisdiction of the
Export Administration Regulations (EAR), 15 CFR 730-774. It cannot be
transferred to any foreign party without the appropriate authorization under
the EAR. Violations of these regulations are punishable by fine, imprisonment,
or both.
===============================================================================

EGView Web die pick map creation report for lot: n06522

Creation Date: 09/04/2024 06:39:00
EGView Web Version: 6.30

  Notch Location: Top
  Rotation Angle Applied from Original: 180 degrees (clockwise)


Wafer Name             Bin 1   Bin 4   Bin 6   Bin 7   Bin 8    Total
====================  ======= ======= ======= ======= =======  =======
N06522-01-F2          18900      81       0       4       5    18990 
N06522-02-A2          18900      50       0      13      27    18990 
N06522-03-C5          18794     193       0       1       2    18990 
N06522-04-F0          18835      75       1      13      66    18990 
N06522-05-A0          18771     211       0       2       6    18990 
N06522-06-C3          18589     394       0       5       2    18990 
N06522-07-E6          18746     240       0       2       2    18990 
N06522-08-H1          18809     178       0       1       2    18990 
N06522-09-C1          18387     598       0       1       4    18990 
N06522-10-H1          18851     134       0       0       5    18990 
N06522-11-C1          18253     732       0       3       2    18990 
N06522-12-E4          18233     753       0       1       3    18990 
N06522-13-G7          18235     742       2       6       5    18990 
N06522-14-B7          18656     328       0       3       3    18990 
N06522-15-E2          18625     362       0       0       3    18990 
N06522-16-G5          18553     429       0       1       7    18990 
N06522-17-B5          18343     646       0       0       1    18990 
N06522-18-E0          18469     510       1       5       5    18990 
N06522-19-G3          18024     963       0       1       2    18990 
N06522-20-E0          18746     237       0       3       4    18990 
N06522-21-G3          18349     634       0       5       2    18990 
N06522-22-B3          18485     497       0       5       3    18990 
N06522-23-D6          18120     868       0       0       2    18990 
N06522-24-G1          18219     765       0       3       3    18990 
N06522-25-B1          17182    1790       1       6      11    18990 


Summary Stats
============================================================
Number of die pick map files created:               25
Number of die pick map errors observed:             0
Number of die pick maps with row/column mismatches: 0
