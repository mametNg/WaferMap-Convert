===============================================================================
Export Classification: EAR99

This document contains controlled technology under the jurisdiction of the
Export Administration Regulations (EAR), 15 CFR 730-774. It cannot be
transferred to any foreign party without the appropriate authorization under
the EAR. Violations of these regulations are punishable by fine, imprisonment,
or both.
===============================================================================

EGView Web die pick map creation report for lot: n01376

Creation Date: 04/12/2024 11:47:17
EGView Web Version: 6.30

  Notch Location: Top
  Rotation Angle Applied from Original: 180 degrees (clockwise)


Wafer Name             Bin 1   Bin 4   Bin 6   Bin 7   Bin 8    Total
====================  ======= ======= ======= ======= =======  =======
N01376-01-D0          18879     100       0       1      10    18990 
N01376-02-F3          18890      27       1      12      60    18990 
N01376-03-A3          18933      53       0       2       2    18990 
N01376-04-C6          18963      24       0       2       1    18990 
N01376-05-F1          18914      69       0       2       5    18990 
N01376-06-A1          18894      22       1      12      61    18990 
N01376-07-C4          18876     110       0       0       4    18990 
N01376-08-E7          18954      28       0       1       7    18990 
N01376-09-H2          18920      70       0       0       0    18990 
N01376-10-E7          18891      29       1      11      58    18990 
N01376-11-H2          18939      46       0       2       3    18990 
N01376-12-C2          18893      24       0      11      62    18990 
N01376-13-E5          18914      74       0       1       1    18990 
N01376-14-H0          18892      25       1      14      58    18990 
N01376-15-C0          18935      54       0       0       1    18990 
N01376-16-E3          18951      29       0       3       7    18990 
N01376-17-G6          18921      67       0       1       1    18990 
N01376-18-B6          18962      24       0       0       4    18990 
N01376-19-E1          18825      93       1      12      59    18990 
N01376-20-B6          18961      28       0       1       0    18990 
N01376-21-E1          18817      96       0      11      66    18990 
N01376-22-G4          18927      61       0       1       1    18990 
N01376-23-B4          18924      64       0       0       2    18990 
N01376-24-D7          18861      40       1      15      73    18990 
N01376-25-G2          18829     156       0       2       3    18990 


Summary Stats
============================================================
Number of die pick map files created:               25
Number of die pick map errors observed:             0
Number of die pick maps with row/column mismatches: 0
